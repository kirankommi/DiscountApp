﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int total = 0;
        int aCount = 0;
        int bCount = 0;
        int cCount = 0;
        int dCount = 0;
        int discount = 0;
        int temp = 0;

        List<string> list = new List<string>();
        string items = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void Submit_Click(object sender, EventArgs e)
        {
            aCount = 0;
            bCount = 0;
            cCount = 0;
            dCount = 0;
            total = 0;
            items = "";

            for (int i = 0; i < list.Count; i++)
            {
                items = items + "," +  list[i];
                itemsLbl.Text = items;

                if (list[i] == "A")
                {
                    aCount = aCount + 1;
                    total = total + 50;
                }
                if (list[i] == "B")
                {
                    bCount = bCount + 1;
                    total = total + 30;
                }
                if (list[i] == "C")
                {
                    cCount = cCount + 1;
                    total = total + 20;
                }
                if (list[i] == "D")
                {
                    dCount = dCount + 1;
                    total = total + 15;
                }
            }

            if(aCount > 2)
            {
                discount = aCount / 3;
                total = total - (20 * discount);
            }
            if (bCount > 1)
            {
                discount = bCount / 2;
                total = total - (15 * discount);
            }
            if(cCount > 0 && dCount > 0)
            {
                if(cCount > dCount)
                {
                    temp = cCount - dCount;
                    discount = cCount - temp;
                }
                if (dCount > cCount)
                {
                    temp = dCount - cCount;
                    discount = dCount - temp;
                }
                if (dCount == cCount)
                {
                    discount = dCount;
                }

                total = total - (5 * discount);
            }

            TotalText.Text = total.ToString();
        }

        private void A_Click(object sender, EventArgs e)
        {
            list.Add("A");
            

            TotalText.Text =  total.ToString();
        }

        private void B_Click(object sender, EventArgs e)
        {
            list.Add("B");
        }

        private void C_Click(object sender, EventArgs e)
        {
            list.Add("C");
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            aCount = 0;
            bCount = 0;
            cCount = 0;
            dCount = 0;
            total = 0;
            items = "";
            list.Clear();
            TotalText.Text = "";
            itemsLbl.Text = "";
        }

        private void D_Click(object sender, EventArgs e)
        {
            list.Add("D");
        }
    }
}
